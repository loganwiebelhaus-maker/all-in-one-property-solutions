# All in one property solutions — Static Site

Simple static, responsive one-page site. Files included:
- index.html
- styles.css
- script.js
- logo.svg
- LICENSE (MIT)

Preview locally
1. Open index.html in your browser (double-click).
2. Or run a local static server:

   Python 3: