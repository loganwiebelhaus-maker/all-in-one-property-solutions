// Basic interactions: year fill, smooth scroll, simple mailto fallback for form
document.addEventListener('DOMContentLoaded', function(){
  // Set copyright year
  const year = new Date().getFullYear();
  const yEl = document.getElementById('year');
  if(yEl) yEl.textContent = year;

  // Smooth scrolling for internal links
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', (e)=>{
      const target = document.querySelector(a.getAttribute('href'));
      if(target){
        e.preventDefault();
        target.scrollIntoView({behavior:'smooth',block:'start'});
      }
    });
  });

  // Contact form: open mail client as fallback
  const form = document.getElementById('contactForm');
  const mailtoBtn = document.getElementById('mailtoBtn');
  function openMailto(data){
    const subject = encodeURIComponent('Website contact from ' + data.name);
    const body = encodeURIComponent(`Name: ${data.name}\nEmail: ${data.email}\n\nMessage:\n${data.message}`);
    window.location.href = `mailto:hello@example.com?subject=${subject}&body=${body}`;
  }

  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      const formData = new FormData(form);
      const data = {
        name: formData.get('name') || '',
        email: formData.get('email') || '',
        message: formData.get('message') || ''
      };

      // Try to use a fetch to send to an API endpoint (commented out) — fallback to mailto
      // Uncomment and set action if you have a backend or form service.
      // fetch('/api/contact', {method:'POST', body: JSON.stringify(data), headers:{'Content-Type':'application/json'}})
      //   .then(()=> alert('Message sent — thank you!'))
      //   .catch(()=> openMailto(data));

      // No backend configured: use mailto fallback
      openMailto(data);
    });
  }

  if(mailtoBtn){
    mailtoBtn.addEventListener('click', function(){
      const name = form.querySelector('[name="name"]').value || '—';
      const email = form.querySelector('[name="email"]').value || '—';
      const message = form.querySelector('[name="message"]').value || '—';
      openMailto({name,email,message});
    });
  }
});